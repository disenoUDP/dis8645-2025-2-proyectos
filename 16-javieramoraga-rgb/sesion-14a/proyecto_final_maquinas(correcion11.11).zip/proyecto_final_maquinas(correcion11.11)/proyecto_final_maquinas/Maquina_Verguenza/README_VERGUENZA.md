# Máquina de la Vergüenza

## Resumen conceptual
Representa la incomodidad y el rechazo a ser observado. En anonimato muestra movimientos tímidos y luz tenue; cuando percibe cercanía o alta "ansiedad" de su hermana, se oculta rápidamente y apaga la luz.

## Materiales
- Arduino UNO + cable USB
- Sensor ultrasónico HC-SR04
- Micro servomotor SG90
- LED (puede ser RGB o simple) + resistencia 220 Ω
- Protoboard y cables

Enlaces (ejemplos):
- HC-SR04: https://afel.cl/products/sensor-de-ultrasonico-hc-sr04
- Servo SG90: https://afel.cl/products/micro-servomotor-sg90
- LEDs: https://afel.cl/products/diodo-led-rgb-5mm

## Conexión (pines por defecto)
- TRIG -> D2
- ECHO -> D3
- SERVO -> D5
- LED PWM -> D6
- SoftwareSerial RX -> D11 (escucha Ansiedad)
- SoftwareSerial TX -> D10 (si fuese necesario)

## Funcionamiento técnico (resumen)
- Mide distancia con HC-SR04 (5–100 cm).
- Decide ocultamiento según distancia y nivel de ansiedad recibido por SoftwareSerial (byte 0–255).
- Si debe ocultarse: mueve servo a ángulo oculto y apaga LED; mantiene mínimo tiempo de cooldown.
- Si no, realiza oscilación tímida y enciende LED tenue.
- Parámetros de umbrales y tiempos son calibrables en el código.

## Notas de montaje
- Asegurar GND común si se usan fuentes externas.
- Calibrar ángulos del servo según la mecánica (ángulos por defecto definidos en código).

## Referencias bibliográficas (selección)
- Zimoun — http://zimoun.net/
- Arduino Reference — https://www.arduino.cc/reference/
- HC-SR04 datasheet / tutorial
- Servo library docs — https://www.arduino.cc/en/Reference/Servo

