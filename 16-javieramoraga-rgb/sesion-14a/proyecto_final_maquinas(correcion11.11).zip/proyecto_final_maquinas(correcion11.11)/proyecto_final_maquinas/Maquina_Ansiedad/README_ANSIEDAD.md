# Máquina de la Ansiedad

## Resumen conceptual
Representa la inquietud y la tensión: vibra constantemente con una tensión de fondo y aumenta su vibración de forma errática a medida que la "hermana" (Máquina de la Vergüenza) se aproxima.

## Materiales
- Arduino UNO + cable USB
- Sensor ultrasónico HC-SR04
- Motor vibrador DC (pequeño, tipo joystick / motor de vibración)
- Protoboard y cables
- (Opcional) Fuente externa para el motor si supera corriente del Arduino
- Resistencias / condensadores según montaje

Enlaces (ejemplos):
- HC-SR04: https://afel.cl/products/sensor-de-ultrasonico-hc-sr04
- Motor vibrador PWM: https://afel.cl/products/motor-vibrador-pwm-switch-dc

## Conexión (pines por defecto)
- TRIG -> D2
- ECHO -> D3
- MOTOR PWM -> D5
- SoftwareSerial RX -> D10
- SoftwareSerial TX -> D11
- GND de la fuente del motor debe estar conectado al GND del Arduino.

## Funcionamiento técnico (resumen)
- Mide distancia con HC-SR04 (5–100 cm).
- Usa un mapeo no lineal para convertir distancia → 'factor de ansiedad'.
- Añade ruido aleatorio y picos con baja probabilidad para lograr vibración errática.
- Transición suave: sube rápido, baja lento (decay prolongado).
- Envía por SoftwareSerial (un byte 0–255) el nivel actual de vibración para que la otra máquina lo interprete.

## Notas de seguridad
- Si el motor consume más de 200 mA, usar fuente externa y MOSFET/driver. Evitar alimentar motores directamente desde Arduino si no estás seguro.
- Añadir condensador de desacoplo y diodo flyback si corresponde.

## Referencias bibliográficas (selección)
- Zimoun — artista sonoro y performático (referente conceptual). http://zimoun.net/
- Arduino Reference — https://www.arduino.cc/reference/
- HC-SR04 datasheet / tutorial — múltiples recursos en línea (Afel product page).
- Documentación Servo: https://www.arduino.cc/en/Reference/Servo


