#ifndef SENSOR_TILT_H
#define SENSOR_TILT_H

// INCLUIR BIBLIOTECAS DE USO PARA SENSOR/ACTUADOR
// #include <arduino.h>

// CREAR LA CLASE DE NUESTRO SENSOR/ACTUADOR
  class SensorTilt {
  public:
  SensorTilt();
// especificar todos los voids que seran utilizados en el archivo.cpp
  void configuracionTilt();
  void funcionaTilt();

// si es que se necesitas especificar variables, deberian ir aqui
// ya sean bool int, ect.



};
#endif