#include "SensorTilt.h"

SensorTilt::SensorTilt() {}