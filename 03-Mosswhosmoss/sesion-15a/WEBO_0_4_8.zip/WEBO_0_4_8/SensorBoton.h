#ifndef SENSOR_BOTON_H
#define SENSOR_BOTON_H

// INCLUIR BIBLIOTECAS DE USO PARA SENSOR/ACTUADOR
 #include <arduino.h>

// CREAR LA CLASE DE NUESTRO SENSOR/ACTUADOR
  class SensorBoton {
  public:
  SensorBoton();
// especificar todos los voids que seran utilizados en el archivo.cpp
  void configuracionBoton();
  void funcionaBoton();

// si es que se necesitas especificar variables, deberian ir aqui
// ya sean bool int, ect.

  bool estadoBoton = false;

  int botonPin = 11;

  int segundos = 0;

  int minutos = 0;




};
#endif