#include "ActuadorLED.h"

ActuadorLED::ActuadorLED() {}

void ActuadorLED::configuracionLED() {}

void ActuadorLED::funcionaLED() {}