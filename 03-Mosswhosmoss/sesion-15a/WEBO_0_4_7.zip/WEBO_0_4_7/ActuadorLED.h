#ifndef ACTUADOR_LED_H
#define ACTUADOR_LED_H

// INCLUIR BIBLIOTECAS DE USO PARA SENSOR/ACTUADOR
// #include <arduino.h>

// CREAR LA CLASE DE NUESTRO SENSOR/ACTUADOR
  class ActuadorLED {
  public:
  ActuadorLED();
 
 
  // especificar todos los voids que seran utilizados en el archivo.cpp
    void configuracionLED();
   
    void funcionaLED();

  // si es que se necesitas especificar variables, deberian ir aqui
  // ya sean bool int, ect.



  };
#endif